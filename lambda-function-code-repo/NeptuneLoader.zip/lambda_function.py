import json
import logging
import signal
import boto3
import os
import time
import requests

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

s3path = os.environ['neptuneloads3path']
neptunedb = os.environ['neptunedb']
iamrole = os.environ['s3loadiamrole']
region = os.environ['region']
    
def lambda_handler(event, context):
    if event['RequestType'] == "Create":
    
        #Build URL for load API request
        loadURL = "https://" + neptunedb + ":8182/loader"
    
        loadHeaders = { 'Content-Type': 'application/json' }
        
        #Build parameters for bulk load request
        loadParameters = json.dumps({
          "source" : s3path, 
          "format" : "csv",  
          "iamRoleArn" : iamrole, 
          "region" : region, 
          "failOnError" : "FALSE"        
        })
        
        #Submit Bulk load request and check response
        #if 200 - proceed with success message back to CFN
        #if not 200 - proceed with failure message back to CFN
        try:
            loadReq = requests.post(loadURL, data=loadParameters, headers=loadHeaders)

            #Account for situation where IAM role has not fully applied to cluster
            #and call to loader occurs.  Wait one second and repeat call to loader.
            retries = 0     
            while (retries < 25):
                if ('code' in json.loads(loadReq.text)) and (json.loads(loadReq.text)['code'] == "InvalidParameterException"):
                    time.sleep(6) #wait 6 seconds
                    loadReq = requests.post(loadURL, data=loadParameters, headers=loadHeaders)
                    retries += 1 #count up tries and exit out after 10
                else:
                    break

            print("DEBUG --- NEPTUNE IAM ROLE APPLIED IN " + str(retries*6) + " seconds")
            if loadReq.status_code != 200:
                print(loadReq.text)
                sendResponseCfn(event, context, "FAILED")
            else:
                sendResponseCfn(event, context, "SUCCESS")
        except requests.exceptions.RequestException as e:
            print(e)
            raise
    else:
        sendResponseCfn(event, context, "SUCCESS")

def sendResponseCfn(event, context, responseStatus):
    response_body = {'Status': responseStatus,
                     'Reason': 'Log stream name: ' + context.log_stream_name,
                     'PhysicalResourceId': context.log_stream_name,
                     'StackId': event['StackId'],
                     'RequestId': event['RequestId'],
                     'LogicalResourceId': event['LogicalResourceId'],
                     'Data': json.loads("{}")}

    requests.put(event['ResponseURL'], data=json.dumps(response_body))
    
