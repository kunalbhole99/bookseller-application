import json
import logging
import signal
import boto3
import os
import requests

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

def lambda_handler(event, context):

    cfnStatus = ""
    cfnMessage = ""
    addRoleResponse = ""

    if event['RequestType'] == "Create":

        #Add IAM role to Neptune Cluster.
        #This role allows the Neptune Cluster to read data from S3.
        #As of 11/02/2018, adding an IAM role to a Neptune  cluster is not available 
        #in CloudFormation.  Instead, we are checking for the role here
        #and adding it if necessary.
    
        neptunedb = event['ResourceProperties']['NeptuneDB']
        iamrole = event['ResourceProperties']['IAMRole']
        region = event['ResourceProperties']['Region']
    
        client = boto3.client('neptune', region_name=region)
        neptuneCluster = client.describe_db_clusters(
            DBClusterIdentifier=neptunedb
        )
        if len(neptuneCluster['DBClusters'][0]['AssociatedRoles']) > 0:
            print("DEBUG -- Neptune Cluster IAM Role already exists")
            print(json.dumps(neptuneCluster['DBClusters'][0]['AssociatedRoles']))
            cfnStatus="SUCCESS"
            cfnMessage="IAM Role Already Exists."
        else:
            try:
                print("DEBUG --- Neptune DB: " + neptunedb + " IAMRole: " + iamrole)
                addRoleResponse = client.add_role_to_db_cluster(
                    DBClusterIdentifier=neptunedb,
                    RoleArn=iamrole
                )
                cfnStatus="SUCCESS"
                cfnMessage="IAM Role " + iamrole + " added to Neptune Cluster."
            except Exception as e:
                print("DEBUG -- Adding IAM role failed.")
                print(e)
                cfnStatus="FAILED"
                cfnMessage=addRoleResponse
                
    elif event['RequestType'] == "Delete":
        
        print("Deleting Custom Resource")
        cfnStatus="SUCCESS"
        cfnMessage="Deleting Custom Resource"
        
    else:
        
        print("This resource cannot be updated.")
        cfnStatus="FAILED"
        cfnMessage="This resource cannot be updated."
        
    #Build response to return to Cloudformation
    response_body = json.dumps({
        "Status": cfnStatus,
        "Reason": "See the details in CloudWatch Log Stream: " + context.log_stream_name,
        "PhysicalResourceId": context.log_stream_name,
        "StackId": event['StackId'],
        "RequestId": event['RequestId'],
        "LogicalResourceId": event['LogicalResourceId'],
        "Data": {"Message": cfnMessage}
    })
    
    #Attempt sending reply back to Cloudformation via pre-signed S3 URL.
    try:
        req = requests.put(event['ResponseURL'], data=response_body)
        if req.status_code != 200:
            print(req.text)
            raise Exception('Received non 200 response while sending response to CFN.')
    except requests.exceptions.RequestException as e:
        print(e)
        raise

    return response_body