import json
import boto3
import requests

def handler(event, context):
    bucketNames = event['ResourceProperties']['BucketNames']
    if event['RequestType'] == 'Delete':
        # Need to empty the S3 bucket before it is deleted
        try:
            s3 = boto3.resource('s3')
            for bucketName in bucketNames:
                bucket = s3.Bucket(bucketName)
                bucket.objects.all().delete()
            sendResponseCfn(event, context, "SUCCESS")
        except Exception as e:
            print(e)
            sendResponseCfn(event, context, "FAILED")
    else:
        sendResponseCfn(event, context, "SUCCESS")

def sendResponseCfn(event, context, responseStatus):
    response_body = {'Status': responseStatus,
                     'Reason': 'Log stream name: ' + context.log_stream_name,
                     'PhysicalResourceId': context.log_stream_name,
                     'StackId': event['StackId'],
                     'RequestId': event['RequestId'],
                     'LogicalResourceId': event['LogicalResourceId'],
                     'Data': json.loads("{}")}

    requests.put(event['ResponseURL'], data=json.dumps(response_body))
