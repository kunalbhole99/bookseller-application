const AWS = require('aws-sdk');
const iam = new AWS.IAM();
const https = require('https');
const url = require('url');
const existingRoleError = 'Service role name AWSServiceRoleForAmazonOpenSearchService has been taken in this account';

exports.handler = function(event, context, callback) {
  console.log('Received event:', JSON.stringify(event, null, 2));
    
  if (event.RequestType === 'Create') {
    createSLR().then(function(data) {
      setTimeout(function() {
        sendResponse(event, callback, context.logStreamName, 'SUCCESS');
      }, 10000);
    }).catch(function(err) {
      if (err.message.includes(existingRoleError)) {
        sendResponse(event, callback, context.logStreamName, 'SUCCESS');
      } else {
        var responseData = { Error: 'Create SLR failed' };
        console.log(responseData.Error);
        sendResponse(event, callback, context.logStreamName, 'FAILED', responseData);
      }
    });
  } else {
    sendResponse(event, callback, context.logStreamName, 'SUCCESS');
    return;
  }
};
    
function sendResponse(event, callback, logStreamName, responseStatus, responseData) {
  const responseBody = JSON.stringify({
      Status: responseStatus,
      Reason: `See the details in CloudWatch Log Stream: ${logStreamName}`,
      PhysicalResourceId: logStreamName,
      StackId: event.StackId,
      RequestId: event.RequestId,
      LogicalResourceId: event.LogicalResourceId,
      Data: responseData,
  });

  console.log('RESPONSE BODY:\n', responseBody);

  const parsedUrl = url.parse(event.ResponseURL);
  const options = {
      hostname: parsedUrl.hostname,
      port: 443,
      path: parsedUrl.path,
      method: 'PUT',
      headers: {
          'Content-Type': '',
          'Content-Length': responseBody.length,
      },
  };

  const req = https.request(options, (res) => {
      console.log('STATUS:', res.statusCode);
      console.log('HEADERS:', JSON.stringify(res.headers));
      callback(null, 'Successfully sent stack response!');
  });

  req.on('error', (err) => {
      console.log('sendResponse Error:\n', err);
      callback(err);
  });

  req.write(responseBody);
  req.end();
}

function createSLR() {
  const params = {
    AWSServiceName: 'opensearchservice.amazonaws.com',
    Description: 'Service linked role for OpenSearch',
  };

  return iam.createServiceLinkedRole(params).promise();
}